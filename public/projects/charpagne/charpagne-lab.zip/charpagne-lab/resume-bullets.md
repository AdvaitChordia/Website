# Resume bullets: Charpagne Research Group

Not web page content. Kept here so the page and the resume stay consistent.

**Simulation Engineering Intern** | Charpagne Research Group, UIUC | Jun 2026 – Present

- Ran a 25-case parametric FEA study in Ansys Explicit Dynamics on bimetallic steel tensile specimens, sweeping reinforcement count and volume fraction to map stiffness, yield strength, and elongation against design variables
- Built all 25 specimen geometries in SolidWorks and SpaceClaim from a parameterized dimension table, scaling an ASTM E8 subsize dogbone by 1.75x to a fixed 10.5 x 3 mm gauge cross section
- Traced a model-wide solver instability to two inherited settings, an incompatible equation-of-state that was silently disabling mass scaling and a timestep floor set four orders of magnitude too high, after ruling out mesh quality by inspection
- Validated the model with a mesh convergence study (converged at 2 mm, 0.5% stress change) and a four-point loading-rate study using kinetic-to-internal energy ratio to confirm quasi-static conditions
- Diagnosed premature failure at 10-12% strain as a truncated material hardening curve rather than a fracture event, confirmed by plastic strain jumping 0.040 to 0.232 in a single timestep at the curve's endpoint
- Established that a fixed per-element failure threshold could not represent confinement-delayed fracture, and rebuilt the failure approach around stress triaxiality instead
- Corrected the load extraction method after finding reaction force at the driven boundary was contaminated by stress-wave ringing, then froze a single protocol applied identically across all 25 runs
- Audited a G-code program for a laser directed energy deposition machine, verifying 120 matched laser on/off pairs and finding a feedrate parameter assigned but never referenced, making an intended speed override inactive

## If space is tight

Four bullets: 1, 3, 4, 6. That set reads as parametric study, solver debugging, validation methodology, and engineering judgment, which is the CAE core. Bullet 8 is the differentiator if the role touches manufacturing or process.

## Notes on wording

The title is framed as an internship rather than a research position, which is a framing choice, not a claim about the appointment. Adjust if a given application needs the literal job title.

Nothing here mentions shared topology. The author stated they are not using it, which conflicts with the research log. Resolve before adding it back.
