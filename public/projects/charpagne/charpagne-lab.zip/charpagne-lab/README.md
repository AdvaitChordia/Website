# Charpagne Lab project page: handoff folder

This folder contains everything needed to build one project page for advaitchordia.com. It is written to be read by another AI tool and turned into a page component. Read this file first.

## Contents

```
charpagne-lab/
  README.md                     you are here
  page.json                     structured content, the source of truth
  page.md                       same content as readable markdown
  resume-bullets.md             separate deliverable, not part of the web page
  assets/
    decision-tree.svg           finished graphic, ready to ship
    images/                     empty, drop screenshots here
```

## What to build

A project detail page matching the existing pattern at `/projects/fsae-struts`. That page has, in order: a back link, a full-width hero image, the title with role and date range, a tag row, a pull quote, a numbered "My Journey" section where each step has a heading, an optional image, and prose, then a "Results" section of short outcome lines, then a "Gallery" of captioned images, then the site-wide contact block.

This page follows the same shape with one addition. A single SVG figure sits between the pull quote and the journey section. It is the spine of the page, so give it room.

## page.json

Use `page.json`, not `page.md`. The markdown is for a human to read; the JSON is the one to parse.

Key fields:

`meta` holds the title, role, organization, date range, tags, and the copy for the project card on the main projects grid.

`hero` and every entry inside `journey[].images` and `gallery[]` reference a `slotId`. Resolve each one against `imageManifest`, which gives the suggested filename, the suggested public path, and alt text.

`figures` holds the decision tree. It ships finished in `assets/decision-tree.svg`. Do not regenerate or restyle it. It is 1000 by 1434 pixels and scales down cleanly. On mobile, let it stay tall rather than shrinking the type until it is unreadable.

`journey` is an array of ten steps, each with `step`, `title`, `images`, and `body`. `body` is an array of paragraphs, already in final wording.

`results` and `gallery` are list-rendered by the site, which is the one place lists are correct on this page.

`authoringNotes` states the constraints. Follow them.

## Images

Every image is a placeholder. `imageManifest[].whatToCapture` describes the specific screenshot or plot that belongs in each slot, and `source` says where it comes from, mostly Ansys Mechanical or the author's Notion research log.

Build the page with the paths wired up even though the files are not here yet. The author drops the files into `assets/images/` using the filenames in the manifest, then they get moved to `/public/projects/charpagne/`. Do not substitute stock imagery or generate placeholder art.

## Rules

Do not change the copy. It has been checked line by line against the author's research log and against Shang et al., Acta Materialia 2026. Every number in it is traceable.

Do not add numbers, round them, or infer new ones. If a figure seems to be missing, it is missing on purpose.

Do not add em dashes. Do not turn prose into bullet points. Do not inflate the language. The register is deliberately plain and the first-person voice is the point of the page.

Two things are left out on purpose and should stay out. The interface treatment, meaning shared topology versus a cohesive zone model, is unresolved between the log and the author's later statement. The composite stress-strain curve has an open unit or scoping error, so no composite curve is claimed as a result anywhere.

## resume-bullets.md

Not part of the web page. It is in this folder because it was produced from the same source material and the author may want the two to stay consistent.
